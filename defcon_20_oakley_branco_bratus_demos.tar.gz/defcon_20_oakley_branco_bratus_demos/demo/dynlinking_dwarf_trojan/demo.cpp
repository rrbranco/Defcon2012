#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void sayHello()
{
  printf("Hi Everyone\n");
}

void sayGoodbye()
{
  printf("Oh, oh, I see! Running away, eh? You yellow bastards! Come back here and take what's coming to you! I'll bite your legs off!");
  exit(0);
}

void sayComment()
{
  printf("Well this is boring so far, isn't it?\n");
}



char buffer[1024];
char* getInput()
{
  fgets(buffer,1024,stdin);
  buffer[strlen(buffer)-1]=0;//kill trailing newline
  return buffer;
}

void doStuff()
{
  printf("Say something\n");
  while(1)
  {
    char* whatToDo=getInput();
    if(!strcmp(whatToDo,"hello"))
    {
      sayHello();
    }
    else if(!strcmp(whatToDo,"what's up"))
    {
      sayComment();
    }
    else if(!strcmp(whatToDo,"bye"))
    {
      sayGoodbye();
    }
    else
    {
      throw -1;
    }
  }
}

int main(int argc,char** argv)
{
  try
  {
    doStuff();
  }
  catch(int a)
  {
    printf("Unexpected input, caught code %i\n",a);
  }
}
